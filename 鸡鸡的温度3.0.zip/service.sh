#!/system/bin/sh
MODDIR=${0%/*}

# 降频策略
HYST_TMP() {
	function mod_hyst_tmp() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='0'
		for i in $(ls -d /sys/devices/virtual/thermal/thermal_zone*/trip_point_*_hyst); do
			name=$(cat "${i%/*}/type" | grep -Ei 'cpu|gpu|ddr|soc|cluster|camera|video|dram|apu|npu|mdmss|nsp|pm.*tz|therm')
			value=$(cat "${i}")
			if test "${name}" != ""; then
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i}"
				chmod a+w "${i}"
				echo "${target_number}" >"${i}"
				chmod 0555 "${i}"
				if test "$(cat "${i}")" != "${target_number}"; then
					umount "$i"
					mount --bind $MODDIR/temp/trip_point_hyst "$i"
				fi
			fi
		done
	}
	mod_hyst_tmp "0"
}

CDEV_TMP() {
	function mod_cdev_tmp() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='0'
		for i in $(ls -d /sys/devices/virtual/thermal/thermal_zone*/cdev*_*_limit); do
			name=$(cat "${i%/*}/type" | grep -Ei 'cpu|gpu|ddr|soc|cluster|camera|video|dram|apu|npu|mdmss|nsp|pm.*tz|therm')
			value=$(cat "${i}")
			if test "${name}" != ""; then
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i}"
				chmod a+w "${i}"
				echo "${target_number}" >"${i}"
				chmod 0555 "${i}"
				if test "$(cat "${i}")" != "${target_number}"; then
					umount "$i"
					mount --bind $MODDIR/temp/limit "$i"
				fi
			fi
		done
	}
	mod_cdev_tmp "0"
}

CUR_TMP() {
	function mod_cur_tmp() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='0'
		for i in $(ls -d /sys/devices/virtual/thermal/cooling_device*/cur_state); do
			value=$(cat "${i}")
			chmod -R 0755 "${i%/*}"
			chmod -R 0777 "${i}"
			chmod a+w "${i}"
			echo "${target_number}" >"${i}"
			chmod 0555 "${i}"
			if test "$(cat "${i}")" != "${target_number}"; then
				umount "$i"
				mount --bind $MODDIR/temp/cur_state "$i"
			fi
		done
	}
	mod_cur_tmp "0"
}

MAX_STATE() {
	function mod_max_state() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='0'
		for i in $(ls -d /sys/devices/virtual/thermal/cooling_device*/max_state); do
			value=$(cat "${i}")
			chmod -R 0755 "${i%/*}"
			chmod -R 0777 "${i}"
			chmod a+w "${i}"
			echo "${target_number}" >"${i}"
			chmod 0555 "${i}"
			if test "$(cat "${i}")" != "${target_number}"; then
				umount "$i"
				mount --bind $MODDIR/temp/max_state "$i"
			fi
		done
	}
	mod_max_state "0"
}

#温度墙
TRIP_TMP() {
	function mod_temp_tmp() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='135000'
		for i in $(ls -d /sys/devices/virtual/thermal/thermal_zone*/*point*temp); do
			name=$(cat "${i%/*}/type" | grep -Ei 'cpu|gpu|ddr|soc|cluster|camera|video|dram|apu|npu|mdmss|nsp|pm.*tz|therm')
			value=$(cat "${i}")
			if test "${name}" != ""; then
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i}"
				chmod a+w "${i}"
				echo "${target_number}" >"${i}"
				chmod 0444 "${i}"
				if test "$(cat "${i}")" != "${target_number}"; then
					umount "$i"
					mount --bind $MODDIR/temp/trip_point_temp "$i"
				fi
			else
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i%/*}/mode"
				echo "disabled" >"${i%/*}/mode"
				chmod 0444 "${i}"
			fi
		done
	}
	mod_temp_tmp "135000"
}

# 伪装温度
TEMP_TMP() {
	function mod_temp_tmp() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='50000'
		for i in $(ls -d /sys/class/thermal/thermal_zone*/temp); do
			name=$(cat "${i%/*}/type" | grep -Ei 'cpu|gpu|ddr|soc|cluster|camera|video|dram|apu|npu|mdmss|nsp|pm.*tz|therm')
			value=$(cat "${i}")
			if test "${name}" != ""; then
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i}"
				chmod a+w "${i}"
				echo "${target_number}" >"${i}"
				chmod 0444 "${i}"
				if test "$(cat "${i}")" != "${target_number}"; then
					umount "$i"
					mount --bind $MODDIR/temp/temp "$i"
				fi
			else
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i%/*}/mode"
				echo "disabled" >"${i%/*}/mode"
				chmod 0444 "${i}"
			fi
		done
	}
	mod_temp_tmp "50000"
}

BATTERY_TMP() {
	function mod_temp_tmp() {
		local target_number="${1}"
		test "$(echo "${target_number}" | grep '^[[:digit:]]*$')" = "" && local target_number='29500'
		for i in $(ls -d /sys/devices/virtual/thermal/thermal_zone*/temp); do
			name=$(cat "${i%/*}/type" | grep -Ei 'battery')
			value=$(cat "${i}")
			if test "${name}" != ""; then
				chmod -R 0755 "${i%/*}"
				chmod -R 0777 "${i}"
				chmod a+w "${i}"
				echo "${target_number}" >"${i}"
				chmod 0555 "${i}"
				if test "$(cat "${i}")" != "${target_number}"; then
					umount "$i"
					mount --bind $MODDIR/temp/battery "$i"
				fi
			fi
		done
	}
	mod_temp_tmp "29500"
}

Run_script_temp() {
	# 降频策略
	HYST_TMP
	CDEV_TMP
	CUR_TMP
	MAX_STATE
	#删除英文前面的#，不要删中文前面的#
	#温度墙
	TRIP_TMP
	# 伪装温度CPU节点温度
	TEMP_TMP
	# 伪装温度电池节点温度
	BATTERY_TMP

	script_name="murongruyan"
	lastID=$(ps -eo pid,args,user,group | grep "$script_name" | grep -v 'grep')
	if [ "$lastID" != "" ]; then
		echo "$lastID" | while read pid name user group; do
			if [ "$$" != "$pid" ]; then
				kill -9 $pid >/dev/null 2>&1
			fi
		done
	fi
	ps -ef | grep "$script_name" | grep -v grep | awk '{print $2}' >/dev/null 2>&1
	pkill -f "$script_name" >/dev/null 2>&1
}

Run_script_temp >/dev/null 2>&1



Wait_until_login() {
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  while [ ! -d "/sdcard/Android" ]; do
    sleep 1
  done
}
Wait_until_login
sh $MODDIR/hons

sleep 3

 set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限，基本不要去动
}

# 关闭温控解除限制
while :
do
    setprop init.svc.thermal-engine stopped
    setprop init.svc.android.thermal-hal stopped
    setprop init.svc.gameopt_hal_service-1-0 stopped
    setprop sys.oplus.cpuctl_extension false
    sleep 1
done


stop horae
echo "0 29500" > /proc/shell-temp
echo "1 29500" > /proc/shell-temp
echo "2 29500" > /proc/shell-temp
