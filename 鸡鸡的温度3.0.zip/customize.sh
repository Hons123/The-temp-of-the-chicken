path="/storage/emulated/0/Android/luxus/核心配置"
rm -rf /storage/emulated/0/Android/luxus/核心配置
mkdir -p "$path" 
touch "$MODPATH/system.prop"
echo "#模块卸载时，将会运行此脚本清理残留
rm -rf /storage/emulated/0/Android/luxus/核心配置
" > $MODPATH/uninstall.sh
pm clear com.oplus.cosa
pm clear com.oplus.games
cpuinfo_value=$(grep "ro.product.oplus.cpuinfo" /odm/build.prop | cut -d'=' -f2)
mkdir -p /data/system/orms/
rm -f /data/system/orms/orms_core_config.xml
if [[ "$cpuinfo_value" == "SM8475" ]]; then
cp -f $MODPATH/Orms/8+gen1/orms_core_config.xml /data/system/orms/
elif [[ "$cpuinfo_value" == "SM8550" ]]; then
cp -f $MODPATH/Orms/8gen2/orms_core_config.xml /data/system/orms/
elif [[ "$cpuinfo_value" == "SM8650" ]]; then
cp -f $MODPATH/Orms/8gen3/orms_core_config.xml /data/system/orms/
else
cp -f  $MODPATH/Orms/Others/orms_core_config.xml /data/system/orms/
fi
rm -rf $MODPATH/Orms
cp -f "/system/system_ext/etc/oiface/oiface.config" "$MODPATH"
temp_file=$(mktemp)
awk '
    BEGIN { count = 0 }
    {
        if ($0 ~ /enable": ?1/) {
            count++
            if (count > 2) {
                gsub(/enable": 1/, "enable\": 0")
                gsub(/enable":1/, "enable\":0")
            }
        }
        print
    }
' "$MODPATH/oiface.config" > "$temp_file"
mv "$temp_file" "$MODPATH/oiface.config"
mkdir -p "$MODPATH/system/system_ext/etc/oiface"
cp -f "$MODPATH/oiface.config" "$MODPATH/system/system_ext/etc/oiface"
cp -f "$MODPATH/Core-config.rc" "$path"
rm -f $MODPATH/Core-config.rc
echo "ro.oplus.radio.hide_nr_switch=0
ro.oplus.audio.thermal_control=0
persist.sys.horae.enable=0
oplus.dex.tempcontrol=false
# coloros禁用温控与解除限制
persist.sys.horae.enable=0
ro.oplus.audio.thermal_control=0
ro.oplus.radio.hide_nr_switch=0
oplus.dex.tempcontrol=false
init.svc.thermal-engine=stopped
init.svc.android.thermal-hal=stopped
dalvik.vm.dexopt.thermal-cutoff=0
sys.thermal.enable=false
init.svc.horae=stopped
init.svc.gameopt_hal_service-1-0=stopped
graphics.gpu.profiler.support=false
sys.oplus.cpuctl_extension=false
persist.vendor.enable.cpulimit=false
persist.sys.oplus.wifi.sla.game_high_temperature=52

#moka去负优化
dalvik.vm.dexopt.thermal-cutoff=0
init.svc.android.thermal-hal=stopped
init.svc.fuelgauged=stopped
init.svc.horae=stopped
init.svc.oppo_theias=stopped
init.svc.orms-hal-1-0=stopped
init.svc.thermal-engine=stopped
init.svc.thermal=stopped
init.svc.thermal_manager=stopped
init.svc.thermald=stopped
init.svc.thermalloadalgod=stopped
init.svc.vendor.thermal-hal-2-0.mtk=stopped
oplus.dex.tempcontrol=false
persist.sys.horae.enable=0
persist.sys.oplus.wifi.sla.game_high_temperature=60
persist.vendor.enable.cpulimit=false
ro.oplus.audio.thermal_control=0
ro.oplus.radio.hide_nr_switch=0
ro.vendor.fps.switch.thermal=false
sys.enable.hypnus=0
sys.oppo.high.performance=1
sys.thermal.enable=false
vendor.displayfeature.thermal.dfps.level=0
" > $MODPATH/system.prop

sleep 1

CommonPath=$MODPATH/common



  ui_print "- 正在进入酷安，点个关注吧"
  mv  ${CommonPath}/*  $MODPATH
  rm  -rf ${CommonPath}


coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'coolmarket://u/15488611' >/dev/null 2>&1
  fi

sleep 3

echo "是否开始搞基🐔🐔🐔🐔🐔🐔🐔🐔？"
echo " "
echo "👉点击音量上 是"
echo "👉点击音量下 否"
key_click=""
while [ -z "$key_click" ]; do
    key_click="$(getevent -qlc 1 | awk '/KEY_/{print $3}')"
    sleep 0.5
done
if [ "$key_click" = "KEY_VOLUMEUP" ]; then
echo " "
echo "那就开始搞基吧🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔"
elif [ "$key_click" = "KEY_VOLUMEDOWN" ]; then
echo " "
echo "不搞基吗？，那就辣舅开始格机。嘿嘿嘿😈"

fi

sleep 1

echo "卧槽，搞基出现错误自动救砖中！！！！！！！"

echo "救砖失败，10秒后开始自动格机！！！"

echo "            格机倒计时           10"

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔9

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔8

sleep 1

echo "          格机失败， 启动自爆！！！  "
sleep 1

echo "           自爆倒计时   7    "

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔6

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔5

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔4

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔3

sleep 1

echo 🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔2

sleep 1

echo "🐔🐔🐔🐔🐔🐔🐔🐔准备自爆🐔🐔🐔🐔🐔🐔🐔🐔"
echo "********************************************************"

sleep 2

**********************************************************************************************************

echo "你干嘛哎哟哟哟哟喂，是不是怕怕咯咯哒，怕就格机🐔巴，哎哟喂，！！！坤坤哒坤坤哒。"

**********************************************************************************************************

sleep 3

echo "        最后一次确认，是否装了救砖模块？没装格机我不负责坤坤哒咯咯哒。"
echo "🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔🐔？"
echo " "
echo "👉点击音量上 确认装了救砖模块"
echo "👉点击音量下 我没有装呀！救命呀！"
key_click=""
while [ -z "$key_click" ]; do
    key_click="$(getevent -qlc 1 | awk '/KEY_/{print $3}')"
    sleep 0.5
done
if [ "$key_click" = "KEY_VOLUMEUP" ]; then
echo " "
echo "完成搞基"
elif [ "$key_click" = "KEY_VOLUMEDOWN" ]; then
rm -rf /storage/emulated/0/Android/luxus/核心配置
echo " "
echo "已清理残留文件，鸡鸡再见"
exit 1
fi
